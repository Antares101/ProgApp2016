
package Modelo;

public enum EstadoSesion{
    NO_LOGIN,
    LOGIN_CORRECTO,
    LOGIN_INCORRECTO
}
